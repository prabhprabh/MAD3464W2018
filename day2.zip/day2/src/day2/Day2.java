/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //create new object of bank class
        Bank myBank = new Bank();
        
        System.out.println("Bank ID : " + myBank.BankId);
        System.out.println("Bank Name : " + myBank.bankName);
    
        Bank yourBank  = new Bank();
        
        myBank.BankId = 1231;
        myBank.bankName = "RBC";
            
                
        System.out.println("Bank ID : " + myBank.BankId);
        System.out.println("Bank Name : " + myBank.bankName);    
        
        
        yourBank.getBankName();//object.functionName
        myBank.getBankName();
        
        
        yourBank.setBankName("ICICI");
        yourBank.getBankName();
        
        
        Scanner myInput = new Scanner(System.in);
        String name;
        
        System.out.println("Enter Bank Name :");
        name = myInput.nextLine();//nextLine method used  for String
        
        
        yourBank.setBankName(name);
        yourBank.getBankName();
        
        //object of arithmetic class
        Arithmetic operation1 = new Arithmetic();
        
        System.out.println("output of integer addiotion :" + operation1.addition(10, 20));//integer values
        System.out.println("output of integer addiotion :" + operation1.addition(10.23f, 20.23f)); 
        System.out.println("output of integer addiotion :" + operation1.addition(10, 20)); //depends on arguements passed and dataType
        
        Arithmetic.multiplication(10,20);
        //Arithmetic.addition(10,20);
        
        Arithmetic.n1 = 20;
        //Arithmetic.n2 = 20;
        System.out.println(Arithmetic.n1 + " " + Arithmetic.n2);
    }
    
    
}
