/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Employee extends Person {    //Inheriting person class
    double salary;
    
    
    Employee(){
        super();
        this.salary =14;
        
    }
    
    
    Employee(double pay){
        this.salary = pay;
        
    }
    
    
    Employee(String fname, String lname, int age, double pay){
        super(fname,lname,age);
        this.salary = pay;
    }
    void read(){
        //super.readData();
        Scanner input = new Scanner(System.in);
        System.out.println("salary:");
        this.salary = input.nextDouble();
    }
    
    
    void display(){
        //super.displayData();
        System.out.println("salary" + this.salary);
        
    }
    
    
    
    
    
    
}
