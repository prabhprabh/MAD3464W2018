/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author macstudent
 */
public class Inheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     Person one = new Person();
     //one.readData();
     //one.displayData();
     
     
     Person Prabh = new Person("prabh","chahal",20);
     //Prabh.displayData();
     
//     Person Prabh2 = new Person(prabh);
//     Prabh2.displayData();
    
    Employee e1 = new Employee(1450.57);
    e1.display();
    
    Employee E2 = new Employee();
    E2.display();
    
    
    E2.firstName="prabh";
    E2.lastName="prabh";
    E2.age=10;
    E2.salary =1000;
    //E2.displayData();
    E2.display();
    
    //method Overriding,same method     in  sub and super class
    //Employee E3 = new Employee("prabh","prabh",10,2000);
    Employee E3 = new Employee();
    E3.read();
    E3.display();
            
            


//System.out.println("lastName: " +E2.lastName);
    
    
    
    }
    
}
