/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
 public class Person {
    
    
        String firstName;
        String lastName;
        int age;
        
        //deafult constructor,name always same as class
        
        Person(){
            this.firstName = "Unknown";
                    this.lastName = "Unknown";
                            this.age = 1;
        }
        
        //parameterized constructor
        Person(String fNm, String lNm, int age){
            this.firstName = fNm;
                    this.lastName = lNm;
                            this.age = age;
        }
        
        //copy constructor
        Person(Person object){
            this.firstName = object.firstName;
            this.lastName = object.lastName;
            this.age = object.age;
        }
        
        void readData(){
            Scanner input = new Scanner(System.in);
            
            System.out.println("firstname");
            this.firstName = input.nextLine();
            
            System.out.println("lastname");
            this.lastName = input.nextLine();
            
            
            System.out.println("age");
            this.age = input.nextInt();
            
            
        }
        void displayData()
                
        {
            System.out.println("firstname" + firstName);
            System.out.println("firstname" + lastName);
            System.out.println("firstname" + age);
        }
    
    
}
