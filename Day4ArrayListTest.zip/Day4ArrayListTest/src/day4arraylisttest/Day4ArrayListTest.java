/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4arraylisttest;

import java.util.ArrayList;

import java.util.Collections;
import java.util.Collection;
/**
 *
 * @author macstudent
 */
public class Day4ArrayListTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Books book1 = new Books(1,"The Sky",8);
        Books book2 = new Books(2,"Necklace",3);
        Books book3 = new Books(3,"Milk",2);
        Books book4 = new Books(4,"Journey",3);
        Books book5 = new Books(5,"Wondered",4);
        
        ArrayList<Books> library = new ArrayList<Books>();
        library.add(book1);
        library.add(book2);
        library.add(book3);
        library.add(book4);
        library.add(book5);
        
        System.out.println("No. Of Books "+library.size());
        library.add(2,new Books(10,"Pecific",9));
        
        
        
//        for (Books bk: library){
//            bk.displayInfo();
//            
//        }
        
        library.forEach(bk ->  {
//            bk.displayInfo();
       });
        
        
        Collections.sort(library, new bookTitleComparator());
        Collections.sort(library, new bookRatingComparator());
            for (Books bk: library){
                bk.displayInfo();
            }
     
    
            
            
            
            
            
            
            
            
            
        Student std1 = new Student(1,"Prabh",70.7);
        Student std2 = new Student(2,"Kamal",90.9);
        Student std3 = new Student(3,"Sukh",80.88);
    
    ArrayList<Student> detail = new ArrayList<Student>();
        detail.add(std1);
        detail.add(std2);
        detail.add(std3);
        
    System.out.println("No. Of Students "+detail.size());
        
        
        
        
//        for (Student st: detail){
//            st.displayInfo();
//            
//        }
//        
//        detail.forEach(st ->  {
//            st.displayInfo();
//        });
    
    
    
    Collections.sort(detail, new PercentageComparator());
            for (Student st: detail){
                st.displayInfo();
            }
    
    
    
    }    
}
