/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4arraylisttest;
import java.util.Comparator;
/**
 *
 * @author macstudent
 */
public class Books {
    int bookId;
    String bookTitle;
    int bookRating;
    
    Books(){
        this.bookId = 0;
        this.bookTitle = "Unknown";
        this.bookRating = 0;        
    }
    
    Books(int bookId, String bookTitle, int bookRating){
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.bookRating = bookRating;
        
    }
    
    
    void setID(int ID){
        this.bookId = ID;
     }
    
    int getID(){
        return this.bookId;
    }
    
    void setTitle(String Title){
        this.bookTitle = Title;
     }
    
    String getTitle(){
        return this.bookTitle;
    }
    
    void setRating(int Rating){
        this.bookRating = Rating;
     }
    
    int getRating(){
        return this.bookRating;
    }
    
    void displayInfo(){
        System.out.println("BookID :"+this.bookId + "\n Book Title :" +this.bookTitle + "\n Book Rating :" +this.bookRating);
             
    }
    
}





class bookRatingComparator implements Comparator<Books>{

    @Override
    public int compare(Books o1, Books o2) {
        if(o1.bookRating == o2.bookRating)
            return 0;
        else if(o1.bookRating < o2.bookRating)
            return 1;
        else 
                return -1;
        
    }
    
}
class bookTitleComparator implements Comparator<Books>{

    @Override
    public int compare(Books o1, Books o2) {
      return o1.bookTitle.compareToIgnoreCase(o2.bookTitle);
    
    }
    
}



