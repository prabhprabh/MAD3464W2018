/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4arraylisttest;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Student {
    int StudentID;
    String Name;
    double Percentage;
    
    Student(){
        this.StudentID = 0;
        this.Name = "Unknown";
        this.Percentage = 0;        
    }
    Student(int StudentID, String Name,double Percentage){
        this.StudentID = StudentID;
        this.Name = Name;
        this.Percentage = Percentage;
        
    }
    void setStudeneID(int ID){
        this.StudentID = ID;
     }
    
    int getStudentID(){
        return this.StudentID;
    }
    
    void setName(String Name){
        this.Name = Name;
     }
    
    String getName(){
        return this.Name;
    }
    
    void setPercentage(double Percentage){
        this.Percentage = Percentage;
     }
    
    double getPercentage(){
        return this.Percentage;
    }
    
    void displayInfo(){
        System.out.println("StudentID :"+this.StudentID+ "\n Name :" +this.Name + "\n Percentage :" +this.Percentage);
             
    }
    
}
class PercentageComparator implements Comparator<Student>{
    

    @Override
    public int compare(Student o1, Student o2) {
        if(o1.Percentage == o2.Percentage)
            return 0;
        else if(o1.Percentage < o2.Percentage)
            return 1;
        else 
                return -1;
    
}
}
