/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package classactivityday3;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class ClassActivityDay3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Faculity f = new Faculity();
        f.readdata();
        f.displaydata();
        f.readvalues();
        f.displayvalues();
        
        f.setdata();
        f.getdata();
        
        
        
        
    }
    
}
interface PersonDatabase{
    void readdata();
    void displaydata();
    
}
interface EmployeeDatabase{
    void readvalues();
    void displayvalues();
    
}
interface FaculityDatabase{
    void setdata();
    void getdata();
    
}

class Person implements PersonDatabase {
    String name;
    int age;
    Scanner input = new Scanner(System.in);  
    
    
    
    @Override
    public void readdata() {
     
     System.out.println("Enter a Name: ");
     name = input.nextLine();
     
     System.out.println("Enter a Age: ");
     age = input.nextInt();
    }

    @Override
    public void displaydata() {
        System.out.println("Name is : " +name);
        
        System.out.println("Age is : " +age);
    }
    
}
//class Employee implements EmployeeDatabase{
//    String type;
//    double salary;
//Scanner input = new Scanner(System.in); 
//
//
//    @Override
//    public void readvalues() {
//        Scanner input = new Scanner(System.in);  
//     System.out.println("Enter a Type: ");
//     System.out.println("Enter a Salary: ");
//    }
//
//    @Override
//    public void displayvalues() {
//        System.out.println("Type is" +type);
//        System.out.println("Salary is" +salary);
//    }
//    
//}

class Faculity extends Person implements FaculityDatabase,EmployeeDatabase{
    String course;
    String type;
    double salary;
    Scanner input = new Scanner(System.in); 

    @Override
    public void setdata() {
          
     System.out.println("Enter a Course : ");
     course = input.nextLine();
    }

    @Override
    public void getdata() {
        System.out.println("Course is :" +course);
    }

    @Override
    public void readvalues() {
       
     System.out.println("Enter a Type: ");
     type = input.nextLine();
     System.out.println("Enter a Salary: ");
     salary = input.nextDouble();
    }

    @Override
    public void displayvalues() {
        System.out.println("Type is" +type);
        System.out.println("Salary is" +salary);
    }
    
}