/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;

import java.util.Scanner;

/**
 *
 * @author prabh
 */
public class Seating {
    
    
 int airline[] = new int[11];
    void smoking(){
        
        int seat;
        for(seat=1;seat<=5;seat++){
            if(airline[seat] == 0){
                airline[seat] = 1;
                System.out.println(".....Boarding pass..... ");
                System.out.println("Your Seat number is : " +seat);
                System.out.println("Your Reservation area is : Smoking");
                break;
            }else if (airline[5] == 1){
                System.out.println("Flight is full. Do you want to make resevation in non-smoking..?? Please answer Y for yes and N for No ");
                Scanner input = new Scanner(System.in);
                String answer = input.nextLine();
                if("Y".equals(answer)){
                    nonsmoking();
                 break;
                }else if ("N".equals(answer)){
                   System.out.println("Next flight is after 3 hours. Thank You");
                   break;
                }
            }
            
        }
    }
    void nonsmoking(){
        int seat;
        for(seat=6;seat<=10;seat++){
            if(airline[seat] == 0){
                airline[seat] = 1;
                System.out.println(".....Boarding Pass.....");
                System.out.println("Your Seat number is : " +seat);
                System.out.println("Your Reservation area is: non-smoking");
                break;
            }else if (airline[10] == 1){
                System.out.println("Flight is full you want to make resevation in smoking ");
                Scanner input = new Scanner(System.in);
                String answer = input.nextLine();
                if("yes".equals(answer)){
                    smoking();
                    break;
                }else if("no".equals(answer)){
                   System.out.println("Next flight is after 3 hour");
                   break;
                }
            }
            
        }
        
        
    }
    
}

