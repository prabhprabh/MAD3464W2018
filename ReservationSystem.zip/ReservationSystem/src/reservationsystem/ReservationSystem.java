/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;

import java.util.Scanner;

/**
 *
 * @author prabh
 */
public class ReservationSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner input = new Scanner(System.in);
     
         
         
         
        
        Seating airline = new Seating();
        System.out.println("Please type 1 for smoking or Type 2 for non-smoking");
        int Seat = input.nextInt();
        if(Seat == 1){
            airline.smoking();
             airline.smoking();
              airline.smoking();
               airline.smoking();
                airline.smoking();
                 airline.smoking();
                 
        }else if(Seat == 2){
            airline.nonsmoking();
        }
        
        
        
        
        
    }
    
}
